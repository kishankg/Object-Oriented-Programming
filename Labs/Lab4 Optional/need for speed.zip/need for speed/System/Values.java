package System;
/**
 * 
 * @author Poojan Thaker
 *
 */
public class Values
{
    public static final int SCREEN_WIDTH =480;
    public static final int SCREEN_HEIGHT =480;
    public static final int MAX_LINES=5;
    public static final int MAX_CARS=2;
    public static final int CAR_START_X = 215;
    public static final int CAR_START_Y = 320;
    public static final int CAR_WIDTH = 70;
    public static final int CAR_HEIGHT = 140;
    public static final int SPEED=10;
    public static final int CAR_SPEED = 2;
    public static final int ROAD_LEFT_B = 80;
    public static final int ROAD_RIGHT_B = 380;
    public static final int ROAD_WIDTH = ROAD_RIGHT_B-ROAD_LEFT_B;
}
