/** *
 * @author Renuka,Kajal,Surbhi
 * @version 23 Feb, 2019
 */



import java.time.LocalDate;
import java.util.Date;
/**
 *Person is an abstract class. It is a Public class. It has fields: ID, name, address, email and status of type String and fields doj and dob of type Date;
 */
public abstract class Person {

	private String ID,name,address,email,status;
	public Date doj;
/**
 * Person constructor has fields: ID, name, address, email, doj.
 * @param ID       Institute ID of the person
 * @param name     Name of the person
 * @param address  Address of the person
 * @param email   Email Id
 * @param doj     Date of Joining
 */
	public Person(String ID,String name,String address,String email,Date doj)
	{
		
		
		this.ID=ID;
		this.name=name;
		this.address=address;
		this.email=email;
		//this.status=status;
		this.doj=doj;
	}
/**
 * get_ID() method is a final getter method of type String which returns the ID of Person.
 */
	protected final String get_ID()
	{
		return ID;
	}

	/*
	 * final void set_ID(String ID) { this.ID=ID;
	 * 
	 * }
	 */
	/**
	 * get_name() is final getter method of type String and it returns the name of Person.
	 */

	protected final String get_name()
	{
		return name;
	}

	/*
	 * final void set_name(String name) { this.name=name; }
	 */
	/**
	 * get-address() is a getter method of type String that returns the address of the Person.
	 */
	 protected String get_address()
	{
		return address;
	}

	/*
	 * void set_address(String address) { this.address=address; }
	 */
	 /**
	  * get_email() is a getter method that returns the email of a Person.
	  */
	 
	 protected String get_email()
	{
	   return email;
	}

	/* 
	
	public abstract String toString();
	
	int eligible_rank() // dynamic method dispatch
	{
		return 0;
		
	}
	*/
}





