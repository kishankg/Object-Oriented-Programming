

import java.time.LocalDate;
import java.util.Date;
/**
 * Staff is a public class inherited from Employee and thus it extends Employee class. It has fields HRA of type double and qualification of type String.
 */

public final class Staff extends Employee {

	
	private double HRA;
	private String qualification;
/**
 * Staff constructor has fields ID, name, address, email, doj, salary, qualification.
 * @param ID
 * @param name
 * @param address
 * @param email 
 * @param doj
 * @param salary
 * @param qualification   Educational qualification of the staff
 */
	public Staff(String ID,String name,String address,String email,Date doj,double salary,String qualification)
	{
		super(ID,name,address,email,doj,salary);
		//this.HRA=HRA;
		this.qualification=qualification;
		
	}
	
	/**
	 * basic_salary is passed to method get_HRA() and get_HRA() calculates and returns the HRA of the Staff. 
	 * HRA is calculated as  basic_salary*10/100.
	 */
	
	protected double get_HRA(double basic_salary)
	{
		return basic_salary*10/100;
	}
	
	/**
	 * calculate_salary() is an overridden method which returns sum of calculate_salary(ByPercent) from the inherited class and get_HRA(get_Salary().
	 */
	//overridden method
	 protected double calculate_staff_salary(double ByPercent)
	 {
		
		 return super.calculate_salary(ByPercent)+get_HRA(get_Salary());
	 }
	 /**
	  * eligible_rank() calculates the eligible rank of the Staff. 
	  * use date of joining to calculate the number of years spent by the staff member in the organisation.
	  * If a staff member is 'Graduate and above' and he has spent more than 5 years in the organisation return 1.
	  * If a staff member is 'Grade 12th and above' qualified and he has worked for more than 4 years in the organisation return 2.
	  * If a staff member is 'Grade 12th and above' qualified and he has worked for less than 4 years in the organisation return 3.
	  * 
	  * To get current date use the following syntax and import java.util.Date :
	  * Date d=new Date();
	  * to fetch year from date , use objectname.getYear()
	  */
		protected int eligible_rank() {
			Date d=new Date();
			int diff=d.getYear()-super.doj.getYear();
			if(this.qualification == "Graduate and above" && diff >= 5) return 1;
			else if(this.qualification == "Grade 12th and above" && diff > 4) return 2;
			else if(this.qualification == "Grade 12th and above" && diff < 4) return 3;
			return 0;
		}
	}
	

