
import java.time.LocalDate;
/**
 * Employee class is a Public class that is inherited from Person, thus Employee class extends Person class. 
 */
import java.util.Date;
	
	public class Employee extends Person
	{
	/**
	 * salary represents the salary of the employee and DA represents the Dearness Allowance of the employee. They are both of type double.	
	 */
		private double salary,DA;
/**
 * Employee constructor has the fileds given below. Where ID, name, address and email are of string type and doj (date of joining) and salary are of double type.		
 * @param ID
 * @param name
 * @param address
 * @param email
 * @param doj
 * @param salary  Salary of the Employee
 */
		public Employee(String ID,String name,String address,String email,Date doj,double salary)
		{
			super(ID,name,address,email,doj);
			this.salary=salary;
			
		}
/** This  method is used to calculate salary in this ByPercent parameter is passed which is used to calculate the raise salary, It returns sum of salary and DA. */
	 protected double calculate_salary(double ByPercent)
	 {
		
		 raise_Salary(ByPercent);
		 double DA=get_DA();
		 //System.out.println("DA="+DA);
		 return get_Salary()+get_DA();
	 }
/**This method returns the salary. */
		protected double get_Salary()
		{
			return salary;
		}
/** This method is used to calculate the salary by which rate it has been increased. Before calculating the total salary this method should be called. In this ByPercent parameter is passed.It returns the increased salary. */		
		protected double raise_Salary(double byPercent)
		{
			double raise=this.salary*byPercent/100;
			this.salary+=raise;
			
			return this.salary;
			
		}
		/** This is an implementation of abstract method, It will print all the Employee details i.e ID,Name,Address,Email,Salary.
		 * Each field must be separated by # symbol.
		 *  */
			public String toString()
			{
				return super.get_ID()+"#"+super.get_name()+"#"+super.get_address()+"#"+super.get_email()+"#"+get_Salary();
			}
/** This method calculates the DA, which is 5% of salary. It returns the DA value. */		
			protected double get_DA()
			{
				//System.out.println("salary="+salary);
				return 0.05*salary;
			}
		
	}


