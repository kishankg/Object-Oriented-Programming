


import java.util.Date;

/**
 *Faculty (Public Class) is an inherited class that extends class Employee. It has fields office_hours of type int, office_no of type String and no_of_publications of type int.
 */

public final class Faculty extends Employee {
	
	
	private int no_of_publications;
	/**
	 * Constructor Faculty has fields ID, name, address, email, doj as date of joining, salary and no_of_publications.
	 * @param ID
	 * @param name
	 * @param address
	 * @param email
	 * @param doj
	 * @param salary
	 * @param no_of_publications   Count of research publications of the faculty
	 */
	public Faculty(String ID,String name,String address,String email,Date doj,double salary,int no_of_publications)
	{
		super(ID,name,address,email,doj,salary);
		//this.office_hours=office_hours;
		//this.office_no=office_no;
		this.no_of_publications=no_of_publications;
	}
	

	/**
	 * calculate_faculty_salary() is a method that calculates the salary of the Faculty and returns it
	 * @param ByPercent
	 * @return
	 */
	 protected double calculate_faculty_salary(double ByPercent)
	 {
		return super.calculate_salary(ByPercent);
	 }
	 
	 /**
	  *eligible_rank()  calculates a faculties position in the organisation like assistant professor, associate professor, professor or a senior professor. 
	  *use doj field to calculate the number of years spent in the organisation by the faculty.
	  *The eligibility criterion is:  
	  *if a faculty is in the oragnisation for more than 10 years and he/she has published more than ten no_of_publications then return 1.
	  *if a faculty is in the oragnisation for more than 4 years and less than 6 years and he/she has published more than seven no_of_publications then return 2.
	  *if a faculty is in the oragnisation for more than 2 years and he/she has published more than two no_of_publications then return 3.
	  *else return 0.
	  *
	  * To get current date use the following syntax and import java.util.Date :
	  * Date d=new Date();
	  * to fetch year from date , use objectname.getYear()
	  */
		protected int eligible_rank() {
		
		
		//System.out.println("doj="+ this.doj);
//		Date d=new Date();
//			
//	    String strDateFormat = "yyyy";
//	    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
//	    String curryear= dateFormat.format(d);
//		
//	    String dojyear= dateFormat.format(this.doj);
//		
//	   
//		//System.out.println("year1="+ curryear);
//		//System.out.println("year2="+ dojyear);
//				
//		
//		int diff=Integer.parseInt(curryear)-Integer.parseInt(dojyear);
		
		Date d=new Date();
		int diff=d.getYear()-super.doj.getYear();
		//System.out.println("Faculty Diff="+diff);
		if(diff>10 && this.no_of_publications>10) return 1;
		else if(diff>4 && diff<6 && this.no_of_publications>7) return 2;
		else if(diff>2 && this.no_of_publications>2) return 3;
		else
			return 0;
	}
}
