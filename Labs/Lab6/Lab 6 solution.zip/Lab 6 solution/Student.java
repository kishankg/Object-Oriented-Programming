

import java.util.Date;

public final class Student extends Person {

	private double score;
	private String skill_sets[];	
/**
 * This constructor initializes the member of its parent class as well as it's own class data members. The skill_set is array of size 5.
 * @param ID
 * @param name
 * @param address
 * @param email
 * @param score
 * @param skill_sets
 * @param doj
 */
	Student(String ID, String name, String address, String email, double score, String[] skill_sets, Date doj)
	{
		super(ID,name,address,email,doj);
		this.skill_sets=skill_sets;
		this.score=score;
	}
/** This method returns the score of student. */	
	double  get_Score()
	{
		return score;
	}
/** This method is used to check the eligibility  for various student ranks i.e President, Secretary , Treasurer and Commoner.  .The eligibility criteria is as follows:
skill_set array have the following values: public speaking,management,resource management,finance,problem solving
President: Score greater than and equal to 80 and should possess all 5 skill_sets ,return 1
Secretary: Score greater than and equal to 70 and should possess any of 4 skill_sets,return 2
Treasurer: Score greater than and equal to 50 and should possess any of 3 skill_sets,return 3
else return 4 */	
	int eligible_rank()
	{int j=0;
		for (int i=0;i<5;i++) {
			if(skill_sets[i]=="management")j++;
			if(skill_sets[i]=="public speaking")j++;
			if(skill_sets[i]=="resource management")j++;
			if(skill_sets[i]=="finance")j++;
			if(skill_sets[i]=="problem solving")j++;
		}
		if(score>=80 && j==5)
		{
			return 1; //president
			
		}
		else if(score>=70 && j==4)
		{
			return 2; //Secretary
			
		}
		else if(score>=50 && j==3)
		{
			return 3; //treasurer
			
		}
		else 
			return 4;//common
		
	}
/** This is an implementation of abstract method, It will print all the Employee details i.e ID,Name,Address,Email,Score.
 *  Each field must be separated by # symbol.
 *   */	
	public String toString()
	{
		return super.get_ID()+"#"+super.get_name()+"#"+super.get_address()+"#"+super.get_email()+"#"+get_Score();
	}
	
	
	/*
	 * public static void main(String args[]) {
	 * 
	 * 
	 * Employee eobj,eobj2; //double cal_sal=e.calculate_salary(10);
	 * 
	 * Faculty fobj,fobj2;
	 * 
	 * 
	 * Staff sobj,sobj2; //double staff_sal=sobj.calculate_staff_salary(8); String[]
	 * String[] skill_sets= {"management","public speaking","resource management"
	 * ,"finance","problem solving" };
	 * 
	 * 
	 * 
	 * Student stuobj,stuobj2;
	 * 
	 * Date sDate1=new Date("07/27/2018"); eobj= new
	 * Employee("2018H1400122G","Employee1","CH7","e20180122@goa.bits-pilani.ac.in",
	 * sDate1,700000); Date sDate2=new Date("05/07/2014"); fobj= new
	 * Faculty("F2018H1400115G","Faculty1","CH7","f20180122@goa.bits-pilani.ac.in",
	 * sDate2,900000,9); sobj=new
	 * Staff("S2018H1400138G","Staff1","CH4","s20180122@goa.bits-pilani.ac.in",
	 * sDate2,400000,"Graduate and above"); stuobj=new
	 * Student("ST2018H1400120G","Student1","CH5","st20180122@goa.bits-pilani.ac.in"
	 * ,8.5,skill_sets,sDate1);
	 * 
	 * 
	 * Date sDate3=new Date("05/27/2015"); eobj2= new
	 * Employee("2018H1400124G","Employee2","AH7","e20180124@goa.bits-pilani.ac.in",
	 * sDate3,700000); Date sDate4=new Date("05/17/2017"); fobj2= new
	 * Faculty("F2018H1400185G","Faculty2","AH7","f20180127@goa.bits-pilani.ac.in",
	 * sDate4,900000,9); sobj2=new
	 * Staff("S2018H1400198G","Staff1","CH2","s20180128@goa.bits-pilani.ac.in",
	 * sDate4,500000,"Grade 12th and above"); stuobj2=new
	 * Student("ST2018H1400126G","Student1","CH5","st20180522@goa.bits-pilani.ac.in"
	 * ,8.5,skill_sets,sDate4);
	 * 
	 * System.out.println("Faculty Eligible rank="+fobj.eligible_rank()+" "+fobj2.
	 * eligible_rank());
	 * System.out.println("Staff Eligible rank="+sobj.eligible_rank()+" "+sobj2.
	 * eligible_rank());
	 * System.out.println("Student Eligible rank="+stuobj.eligible_rank()+" "
	 * +stuobj2.eligible_rank());
	 * 
	 * 
	 * System.out.println("Employee Tostring="+eobj.toString()+" "+eobj2.toString())
	 * ;
	 * 
	 * System.out.println("Student Tostring="+stuobj.toString()+" "+stuobj2.toString
	 * ());
	 * 
	 * System.out.println("Employee Caclulated Salary="+fobj.
	 * calculate_faculty_salary(10)+" "+fobj2.calculate_faculty_salary(9));
	 * System.out.println("Staff Caclulated Salary="+sobj.calculate_staff_salary(8)
	 * +" "+sobj2.calculate_staff_salary(6));
	 * 
	 * 
	 * 
	 * }
	 */
	  
	 
}


