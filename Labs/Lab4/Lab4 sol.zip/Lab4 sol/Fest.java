/**
 * The class representing Fest
 * @author Tushar Agarwal,Gurkirat Guliani,Anushka Sham Nayse,Ishaan M Patel
 *
 */
public class Fest{
	/**
	 * array of participants 
	 *
	 */
	public Participant[] participants;
	/**
	 * array of events 
	 *
	 */
	public Event[] events;
	/**
	 * stores the number of participants currently in the fest 
	 *
	 */
	public int noOfParticipants;
	

	/**
	 * Constructor.
	 * 
	 * Initialize array of Participants with size 25
	 * Initialize the Event array with events variable argument passed
	 * Initialize noOfParticapnts with 0
	 * @param events Event- it contains  list of events
	 */
	public Fest(Event... events)
	{
		this.participants=new Participant[25];
		this.events=events;
		noOfParticipants=0;
		
	}
	/**
	 * register the participant for the event and update the participant array with this new participant
	 * @param participant {@code Participant}- object of class Participant
	 * @param events {@code Event}- contains list of events
	 *  
	 * @return number of events not added else return -1 if addEvent returns -1
	 */
	public int register(Participant participant,Event... events)
	{
		int addedEvents=participant.addEvent(events);
		this.participants[noOfParticipants++]=participant;
		if(addedEvents>=0)
		return events.length-addedEvents;
		else return -1;
	}
	
	
}