/**
 * The class representing Participant
 * @author Tushar Agarwal,Gurkirat Guliani,Anushka Sham Nayse,Ishaan M Patel
 *
 */
public class Participant{
	/**
	 * It stores the name of the participant  .
	 */
	private String name;
	/**
	 * It stores the ID of the participant  .
	 */
	private int Id;
	/**
	 * It stores the no of events the participant has taken part in.
	 */
	private int noOfEvents;
	/**
	 * It is an array of all events that a participant is registered in.
	 */
	public Event[] events;
	/**
	 * It stores the total score of the participant
	 */
	private int score;
	/**
	 * This stores the maximum no. of events that a participant can participate in. This is a constant value equal to 5 and can not be changed.
	 */
	public static final int MaxNoOfEvents=5;
	/**
	 * 
	 * The constructor for class {@code Participant}. The constructor takes two
	 * parameters name and id, and assigns these values to {@code name},
	 * {@code Id} fields of class {@code Participant} respectively.
	 * It also initializes the events[] with size = MaxNoOfEvents. 
	 * All the other data members are initialized with the default values according to their data type. 
	 * @param name String-contains name of the participant
	 * @param Id int-contains id of the participant
	 */
	public Participant(String name,int Id){
		this.name=name;
		this.Id=Id;
		noOfEvents=0;
		events=new Event[MaxNoOfEvents];
		this.score=0;
	}
	/**
	 * 
	 * 
	 * This method is used to add new events to events[]. It takes a variable length argument of type Event which consists of all those events
	 * which are to be added. Remember that every event can accommodate only a maximum number of participants and at the same time every participant too  
	 * has a maximum number of events he/she can participate in.Whenever an event is added to a participant's  {@code events},the participant
	 *  should also be added to the participant list of the respective event.Proceed to add events only if total events after adding can be within the given limit
	 * 
	 *  @param eventList {@code Event}- variable length argument of type Event
	 * @return number of events successfully added else return -1 if participant might run out of free slots for events.
	 */
	
	public int addEvent(Event... eventList){
		int noOfEventsAdded=0;
		if(eventList.length+noOfEvents<=MaxNoOfEvents){
			for(Event e: eventList){
				if(e.getNoOfParticipants()<Event.MaxNoOfParticipants){
					this.events[noOfEvents++]=e;
					e.addParticipants(this);
					noOfEventsAdded++;
				}
			}
			return noOfEventsAdded;
		}
		else
			return -1;
	}
	/**
	 * This method is used to get the total score of the participant.
	 * @return score  
	 */
	public int getScore() {
		return score;
	}
	/**
	 *
	 * 
	 * This method is used update the total score of the participant by adding the argument points. 
	 *  @param points int  
	 */
	public void addPoints(int points) {
		this.score += points;
	}
	/**
	 * This method is used to get the name of the participant. 
	 * @return name 
	 */
	public String getName() {
		return name;
	}
	/**
	 * This method is used to get the Id of the participant.
	 * @return Id  
	 */
	public int getId() {
		return Id;
	}
	/**
	 * This method is used to get the number of events the participant has participated in.  
	 * @return number of events
	 */
	public int getNoOfEvents() {
		return noOfEvents;
	}
	/**
	 * This method removes all those events from {@code events}, which have finished. i.e. which have the field {@code hasfinished} equal to "true".
	 * Make sure that the size of {@code events} changes as the events are deleted. 
	 */
	public void removeEvents()
	{
		Event a[]=new Event[MaxNoOfEvents];
		int j=0;
		for(int i=0;i<this.noOfEvents;i++)
		{
			if(events[i].getState()==false)
			{
				a[j++]=new Event(events[i]);
			}
		}
		this.noOfEvents=j;
		events = a;

	}

}	