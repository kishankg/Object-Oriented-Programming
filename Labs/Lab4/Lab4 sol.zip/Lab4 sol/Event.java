/**
 * The class representing Event
 * @author Tushar Agarwal,Gurkirat Guliani,Anushka Sham Nayse,Ishaan M Patel
 *
 */

public class Event{
	/**
	 * it stores the id of the event. 
	 *
	 */
			public int eventNo;
	/**
	 * it stores the name of the event. 
	 */
	
	public String eventName;
	/**
	 * it stores the number of participants currently in the event. . 
	 */
	
	private int noOfParticipants;
	/**
	 * it stores an array of participants who are are participating in the event  
	 */
	
	private Participant[] participants;
	/**
	 * it stores the status of the event. It is true if the event has finished and false otherwise . 
	 */
	
	private boolean hasFinished;
	/**
	 * it stores the maximum number of participants. This value cannot be changed and it is to be shared 
	 * by every object of the class. Its value is 10 . 
	 */
	
	public static final int MaxNoOfParticipants=10;
	/**
	 * Constructor of class {@code Event}.
	 * 
	 * It initializes the data members of the class variables. Expressions with  boolean
	 * data type  with default value. 
	 * It initialize the participant array with MaxNoOfParticipants   
	 * @param eventName String- to initialize eventName
	 * @param eventNo int -event id to initialize eventNo
	 * 
	 *  
	 */
	
	public Event(int eventNo, String eventName)
	{
		this.eventNo=eventNo;
		this.eventName=eventName;
		noOfParticipants=0;
		this.hasFinished=false;
		participants=new Participant[MaxNoOfParticipants];
		
	}
	/**
	 * Copy Constructor 
	 * @param e Event	  
	 */
	public Event(Event e){
		this.eventNo=e.eventNo;
		this.eventName=e.eventName;
		this.noOfParticipants=e.noOfParticipants;
		this.hasFinished=e.hasFinished;
		this.participants=e.participants;
		
	}
	/**
	 *  This method assigns true to hasFinished variable. 
	 
	 */

	public void finishEvent(){
		hasFinished=true;
	}
	
	
	
	/**
	 * 
	 * This method returns the status of hasFinished variable 
	 * 
	 *  @return hasFinsihed
	 
	 */

	public boolean getState()
	{
		return hasFinished;
	}
	/**
	 * 
	 * This method returns the number of participants in the event. 
	 * 
	 * @return noOfParticipants 
	 
	 */
	public int getNoOfParticipants(){
		return noOfParticipants;
	}
	/**
	 * 
	 *  This method is used to add new participants to {@code participants}. It takes a variable length argument of type {@code Participant} which consists of all those participants
	 * which are to be added. Remember that every event can accommodate only a maximum number of participants. 
	 * Add only if all the participants can be added. 
	 * @param participantList {@code Participant} -variable-argument participantList  of type Participant . 
	 *  @return true if addition is successful else false.  
	 */
	public boolean addParticipants(Participant... participantList){
		if(participantList.length+noOfParticipants<=MaxNoOfParticipants){
			for(Participant p: participantList){
				this.participants[noOfParticipants++]=p;
			}
			return true;
		}
		else
			return false;
	}
	/**
	 * 
	 * This method updates the scores of all the {@code participants}.Update only when points for each participant are given as argument.  
	 * @param  points  variable argument points of type int.Contains points earned by each participant in the event.  
	 *  @return true if update is successful else false. 
	 
	 */
	public boolean updateScore(int ...points)
	{
		if(points.length==this.noOfParticipants)
		{
			for(int i=0;i<this.noOfParticipants;i++)
				this.participants[i].addPoints(points[i]);
			return true;
		}
		else 
			return false;

	}
	
	/**
	 * 
	 * 
	 * 
	 * update the score of the participant whose name and id matches with the arguments passed
	 * @param name  String - It stores the name of participants. 
	 * @param Id     int  - It stores the id of the participant. 
	 * @param points  int - it stores the points of participants. 
	 * 
	 * @return true if updateScore is successful else false. 
	 */
	public boolean updateScore(String name,int Id, int points)
	{
		for(Participant p: this.participants)
		{
			if(p.getName().equals(name) && p.getId()==Id)
			{
				p.addPoints(points);
				return true;
			}
		}
		return false;	
	}
}	
	
	