
class Family
{
	Person head;

	public Person getHead()
	{
		return head;
	}
}

@RunWith(MockitoJUnitRunner.class)
public class PersonTest
{
	@BeforeClass
	public void createMocks()
	{
		@InjectMocks
		Family family;

		@Mock
		Person head;

		head = String("head");
		doReturn(head).when(family).getHead();
	}

	@Test
	public void checkMock()
	{
		assertThat(family.getHead()).isEqualTo(head);
	}
}
