package src.java.main;

/**
 * A sample class to describe a quest. This is a class used by Knights to undertake quest.
 * 
 * A sample class written to demonstrate the mocking techniques.
 * @author  TSRK Prasad
 * @version 22-August-2016
 */
public class Quest
{
    public void embark()
    {
        System.out.println("Embarking on a quest.");
    }
}