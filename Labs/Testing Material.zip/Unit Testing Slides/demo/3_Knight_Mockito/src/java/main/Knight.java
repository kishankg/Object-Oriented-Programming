package src.java.main;

/**
 * A knight who goes on a quest to perform heroic deeds. The knight wears a blade for protection.
 * If tired, the knight can retire by gifting away the blade.
 * 
 * A sample class written to demonstrate the mocking techniques.
 * @author  TSRK Prasad
 * @version 22-August-2016
 */
public class Knight
{
    private Quest quest;
    private Blade blade;
    
    public Knight(Quest quest, Blade blade)
    {
        this.quest=quest;
        this.blade = blade;
    }

    public void embarkOnQuest()
    {
        quest.embark();
    }
    
    public boolean prepareForBattle()
    {
        return blade.unsheath();
    }
    
    public Blade retire()
    {
        return blade.giftBlade();
    }
    
    /**
     * prepare for duel; don't actually fight
     */
    public String duelPosture(Knight opponent)
    {
        prepareForBattle();
        opponent.prepareForBattle();
        return "Prepared";
    }
}
