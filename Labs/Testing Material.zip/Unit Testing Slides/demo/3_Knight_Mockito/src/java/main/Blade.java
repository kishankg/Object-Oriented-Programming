package src.java.main;


/**
 * An interface for Blade. Blade is the instrument of choice for knights in this case study.
 * 
 * A sample class written to demonstrate the mocking techniques.
 * @author  TSRK Prasad
 * @version 22-August-2016
 */
public interface Blade
{
    boolean unsheath();
    Blade giftBlade();
}
