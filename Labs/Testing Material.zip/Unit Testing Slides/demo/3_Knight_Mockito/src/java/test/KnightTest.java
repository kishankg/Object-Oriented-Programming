package src.java.test;



import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.mockito.BDDMockito.*;

import src.java.main.*;

/**
 * The test class KnightTest.
 *
 * A sample class written to demonstrate the mocking techniques.
 * @author  TSRK Prasad
 * @version 22-August-2016
 */
public class KnightTest
{
    private Quest mockQuest;
    private Blade mockBlade;
    private Knight knight;
    
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        //arrange - common for all tests
        mockQuest = mock(Quest.class);
        mockBlade = mock(Blade.class);
        knight = new Knight(mockQuest,mockBlade);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
        //dismantle test fixture - common for all methods
        mockQuest = null;
        mockBlade = null;
        knight = null;
    }
    
    /**
     * simple demonstration of arrange-act-assert style
     * 
     * example of mock
     * 
     * embarkOnQuest() is a void type return
     * here we verify the call on the mock
     * by default, all calls to mocked methods of void return type do nothing
     * 
     * calls to mock need to be verified
     */
    @Test
    public void knightShouldEmbarkOnQuest()
    {
        //arrange - all arrangements done in setUp() method
        
        //act
        knight.embarkOnQuest();
        
        //assert
        verify(mockQuest, times(1)).embark();
    }
    
    /**
     * example of mock
     * 
     * embarkOnQuest() is a void type return
     * another way of mocking a method with void return type
     * here, our intention of doing nothing in a method with void return type is explicitly specified
     * 
     * in this test, mockBlade object is acting as a dummy
     * 
     * calls to mock need to be verified
     */
    @Test
    public void knightShouldEmbarkOnQuestExplicitVoid()
    {
        //arrange
        //take care not to arrange on the class under test, i.e., Knight
        doNothing().when(mockQuest).embark();
        
        //act
        knight.embarkOnQuest();
        
        //assert
        verify(mockQuest, times(1)).embark();
    }
    
    /**
     * example of stub
     * 
     * mock call to method setup in arrange-act-assert style. arrange part in the test setup method.
     * mockBlade used as a stub object; default return value of a mocked method is
     * a false value for boolean
     * 
     * in this test, mockQuest object is acting as a dummy
     * 
     * calls to stub are not verified
     */
    @Test
    public void knightPreparesForBattle()
    {
        //act-assert in a single statement
        assertThat("Knight unable to prepare for battle", 
                    knight.prepareForBattle(), is(false));
    }

    /**
     * example of stub
     * 
     * mock call to method setup in arrange-act-assert style. arrange part in the test setup method.
     * mockBlade used as a stub object
     * 
     * calls to stub are not verified
     */
    @Test
    public void knightPreparesForBattleWithStub()
    {
        //arrange - in addition to what is in setUp() method
        when(mockBlade.unsheath()).thenReturn(true);
        
        //act-assert in a single statement
        assertThat("Knight unable to prepare for battle", 
                    knight.prepareForBattle(), is(true));
    }
    
    
    /**
     * example of stub
     * 
     * stub testing using Mockito.
     * Knight.retire() method uses mockBlade as a stub (one kind of test double)
     * 
     * calls to stub are not verified
     */
    @Test
    public void knightRetires()
    {
        //arrange
        when(mockBlade.giftBlade()).thenReturn(mockBlade);
        
        //act-assert
        assertThat(knight.retire(),is(mockBlade));
    }
    
    
    /**
     * example of stub
     * 
     * stub testing using Mockito.
     * in this method, we show a stub method returning null object.
     * 
     * calls to stub are not verified
     */
    @Test
    public void knightRetiresNull()
    {
        //arrange
        when(mockBlade.giftBlade()).thenReturn(null);
        
        //act-assert
        assertThat(knight.retire(),equalTo(null));
    }
    
    /**
     * example of stub
     * 
     * using Mockito to perform behavior driven development (BDD)
     * all BDD tests are in the form given-when-then which is equivalent to arrange-act-assert in TDD
     * 
     * calls to stub are not verified
     */
    @Test
    public void knightRetiresBDDStyle()
    {
        //given - in addition to what is in setUp() method
        given(mockBlade.giftBlade()).willReturn(mockBlade);
        
        //when
        Blade blade = knight.retire();
        
        //then
        //assertThat(knight.retire(),is(mockBlade));
        assertThat(blade,is(mockBlade));
    }
}
