

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;

/**
 * @author  TSRK Prasad
 * @version 12-August-2016
 */
public class LabClassTest
{
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    
    @Test(expected = Exception.class)
    public void obtainStudentsList() throws Exception
    {
        LabClass lab = new LabClass(5);
        lab.getStudents();
    }
    
    @Test
    public void obtainStudentsListUsingExpectedException() throws Exception
    {
        LabClass lab = new LabClass(5);
        thrown.expect(Exception.class);
        thrown.expectMessage("students list not to be given.");
        lab.getStudents();
    }
    
}
