

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author  TSRK Prasad
 * @version 12-August-2016
 */
public class StudentTest
{
    Student student;
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        student = new Student("Asif","054");
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
        student = null;
    }
    
    @Test
    public void createStudentObjects()
    {
        assertEquals("name is wrong","Asif",
                        student.getName());
        assertEquals("name is wrong","054",
                        student.getStudentID());
        assertEquals("name is wrong",0,
                        student.getCredits());
                        
    }
    
	/**
	 * Test for {@link Student#changeName(String replacementName)} and 
	 * {@link Student#getName()}.
	 * 
	 * More elaborate explanation.
	 */
    @Test
    public void changeStudentName()
    {
        String name = new String("Shaik");
        student.changeName(name);
        assertSame("name change test fails",
                    name, student.getName());
    }
    
    @Test
    public void incrementStudentCredit()
    {
        int existingCredits = student.getCredits();
        int newCredits = existingCredits + 6;
        student.addCredits(6);
        //assertThat([value], [matcher statement]);
        assertThat("Student credit increment does not happen",
                    student.getCredits(),is(newCredits));
    }
}
