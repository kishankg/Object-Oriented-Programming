package src.main.java.Courses;


/**
 * Write a description of class Course here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Course
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Course
     */
    public Course()
    {
          System.out.println("course constructed");
    }

    public String getCourseName()
    {
        return "OOP";
    }
}
