package src.test.java.Courses;

import src.main.java.Courses.Course;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseTest
{
    @Test
    public void courseName()
    {
        Course course = new Course();
        assertThat("course name wrong",
                    course.getCourseName(), is("OOP"));
    }
}
