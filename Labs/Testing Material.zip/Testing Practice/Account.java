import java.io.*;

/**
 * The class implements a simple bank account system.
 * @author Varun Yeligar, Omkar Kanade
 * @version 24-1-2019
 */
public class Account {

	/**
	 * It stores the account number of the customer.
	 */
	private int acc_num;

	/**
	 * It stores the name of the customer.
	 */
	private String acc_name;

	/**
	 * It stores the date of creation of the account.
	 */
	private String date_created;

	/**
	 * It stores the current balance of the account.
	 */
	private double balance;

	/**
	 * It stores the rate of interest for the account.
	 */
	private double rate_of_interest;


	/**
	 * The constructor for class {@code Account}. The constructor takes five
	 * parameters acc_num, acc_name, date_created, balance, rate_of_interest, and assigns these values to {@code acc_num},
	 * {@code acc_name}, {@code date_created}, {@code balance}, {@code rate_of_interest} which are the fields of class 
	 * {@code Account} respectively.
	 * 
	 * @param acc_num int value equal to account number of the customer.
	 * @param acc_name String value equal to name of the customer.
	 * @param date_created String value equal to date of creation of the account.
	 * @param balance double value equal to balance of the account at the time of creation.
	 * @param rate_of_interest double value equal to rate of interest for the account.
	 */
	public Account(int acc_num, String acc_name, String date_created, double balance, double rate_of_interest) {
		this.acc_num = acc_num;
		this.acc_name = acc_name;
		this.date_created = date_created;
		this.balance = balance;
		this.rate_of_interest = rate_of_interest;
	}

	/**
	 * The function returns the current balance of the account.
	 * It returns the balance in 'long' format.
	 * @return The current balance in 'long' format
	 */
	public long getBalance() {
		return (long) balance;
	}


	/**
	 * The function increments the account's balance by the amount passed as a parameter and returns true.
	 * @param amount The amount to be deposited
	 * @return returns a boolean value which is true
	 */
	public boolean deposit(double amount) {
		balance += amount;
		return true;
	}


	/**
	 * The function decrements the account's balance by the amount passed as a parameter.
	 * It should ensure that the balance is decremented only if the amount passed is less than the account's balance.
	 * @param amount The amount to be withdrawn
	 * @return returns a boolean value which is true if the withdrawal is successful else false
	 */
	public boolean withdraw (double amount) {
		if (balance < amount) {
			return false;
		}
		else {
			balance -= amount;
			return true;
		}
	}


	/**
	 * The function calculates the interest accumulated on the current account balance after
	 * the given number of years.
	 * For the rate of interest, use the class variable rate_of_interest
	 * Assume it to be simple interest. Use the formula:	
	 * 		interest = (P * t * (r/100))
	 * @param num_of_years The number of years
	 * @return The interest accumulated after the given number of years in 'long' format
	 */
	public long interestOnDeposit(int num_of_years) {
		double interest = balance * (rate_of_interest/100) * num_of_years;
		return (long) interest;
	}


	/**
	 * The function calculates the total value to be paid after the given number of years at
	 * the given rate of interest for the given amount.
	 * Assume it to be simple interest. Use the formulae:	
	 * 		interest = (P * t * (r/100))
	 * 		total value = (loaned amount + interest) 
	 * The loaned amount should be added to the account balance.
	 * Return the total value to be paid after the given number of years in 'long' format.
	 * @param amount The loan amount
	 * @param rate_of_interest The interest rate
	 * @param num_of_years The number of years
	 * @return The total value in 'long' format
	 */
	public long takeLoan(double amount, float rate_of_interest, int num_of_years) {
		double interest = amount * (rate_of_interest/100) * num_of_years;
		balance += amount;

		double final_amount = amount+interest;
		return (long) final_amount;
	}



}