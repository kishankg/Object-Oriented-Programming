package exceptions;
/**
 * 
 * User Defined Exception class for catching exception raised if sufficient terminals are not available 
 * @author Omkar Kanade, Sri Hari Raju.
 *
 */
public class NotAvailableException extends Exception {
	/**
	 * store the terminal name
	 */
	String terminalName;
	/**
	 * constructor for NotAvailableException class which initializes terminalName field
	 * @param name Name of the Terminal that is not available 
	 */
	public NotAvailableException(String name)
	{
		this.terminalName = name;
	}
	/**
	 * Overrides the getMessage function of the Exception class. Prints and returns a custom error message<br>
	 * Use System.out.println() for printing. The string that will be printed is ("Terminal "+ terminalName + " is not available").<br>
	 * @return a string in the format: "Terminal "+ terminalName + " is not available".<br> 
	 * Ex: "Terminal A is not available"
	 */
	@Override
	public String getMessage()
	{
		System.out.println("Terminal "+ terminalName + " is not available");
		return "Terminal "+ terminalName + " is not available";
	}

}