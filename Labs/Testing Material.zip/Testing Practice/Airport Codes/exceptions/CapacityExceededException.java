package exceptions;
import exceptions.*;
import main.*;

/**
 * 
 * User Defined Exception class for catching exception if capacity exceeds 
 * @author Omkar Kanade, Sri Hari Raju.
 *
 */
public class CapacityExceededException  extends Exception{
	/**
	 * stores capacity
	 */
	private int capacity;
	/**
	 * stores name
	 */
	private String name;
	/**
	 * Constructor for CapacityExceededException which initializes capactity and name fields
	 */
	public CapacityExceededException(int capacity,String name)
	{
		this.capacity = capacity;
		this.name = name;
		//super(s + " capacity is " + capacity);
	}
	/**
	 * Overrides the getMessage function of the Exception class. Prints and returns a custom error message<br>
	 * Use System.out.println() for printing. The string that will be printed is (name + " capacity is " + capacity).<br>
	 * @return name + " capacity is " + capacity.<br> 
	 * Ex: "Goa Airport capacity is 8"
	 */
	@Override
	public String getMessage()
	{
		System.out.println (name+ " capacity is "+ capacity);
		return name+" capacity is "+capacity;
	}

}