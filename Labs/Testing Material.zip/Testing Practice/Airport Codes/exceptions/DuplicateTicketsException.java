package exceptions;
import main.*;
/**
 * 
 * User Defined Exception class for catching exception raised if there are duplicate tickets 
 * @author Omkar Kanade, Sri Hari Raju.
 *
 */
public class DuplicateTicketsException extends Exception {
	/**
	 * Stores the name of first passenger passed as argument in the constructor 
	 */
	private String passengerName1;
	/**
	 * stores the name of second passenger passed as argument in the constructor
	 */
	private String passengerName2;
	/**
	 * stores the ticketNumber found common between two passengers
	 */
	private String commonTicketNumber;
	/**
	 * Constructor for DupplicateTicketsException class which initializes all the fields
	 * @param p1 the first passenger
	 * @param p2 the second passenger
	 */
	public DuplicateTicketsException(Passenger p1, Passenger p2)
	{
		this.passengerName1 = p1.getName();
		this.passengerName2 = p2.getName();
		this.commonTicketNumber = p1.getTicketNumber();
		//super(p1.getName() + " and " + p2.getName() + " have same tickets");
	}
	/**
	 * Overrides the getMessage function of the Exception class. Prints and returns a custom error message<br>
	 * Use System.out.println() for printing. The string that will be printed is (passenger1 + " and " +passenger2
	 * + " have the same ticket "+ ticketNumber).<br>
	 * @return
	 * passenger1 + " and " +passenger2 + " have same ticket "+ ticketNumber.<br> 
	 * Ex: "xyz and abc have same ticket ticket_1"
	 */
	public String getMessage()
	{
		System.out.println(passengerName1 + " and " + passengerName2 + " have same ticket " + commonTicketNumber);
		return passengerName1 + " and " + passengerName2 + " have same ticket " + commonTicketNumber;
	}
	
}
