package main;

import java.io.ByteArrayOutputStream;

public class MainCheck {
	public static void main (String args[]) {
		Passenger[] passArr1, passArr2, passArr3, passArr4;
		String meal1[];
		String meal2[], meal3[];
		Crew crew[];
		int depTime1[], depTime2[], depTime3[], depTime4[], depTime5[];
		final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
		Airport ap1, ap2, ap3, ap4;
		Terminal t1, t2, t3, t4, t5;
		Plane p1, p2, p3, p4, p5;
		
		passArr1 = new Passenger[4];
		meal1 = new String[] {"veg roll", "coke", "sandwich", "cake"};
		passArr1[0] = new Passenger("abc", "tick_1", 1000, meal1);
		
		meal2 = new String[] {"nonveg roll", "fanta", "pizza", "ice cream"};
		passArr1[1] = new Passenger("def", "tick_2", 2000, meal2);
		
		meal3 = new String[] {"veg roll", "fanta", "burger", "pasta"};
		passArr1[3] = new Passenger("pqr", "tick_3", 6000, meal3);
		
		crew = new Crew[2];
		depTime1 = new int[] {10, 30, 2};
		depTime2 = new int[] {0, 45, 4};
		depTime3 = new int[] {12, 10, 2};
		depTime4 = new int[] {23, 25, 3};
		depTime5 = new int[] {23, 30, 4};
		
		t1 = new Terminal("term_1", true);
		t2 = new Terminal("term_2", false);
		
		t3 = new Terminal("term_3", true);
		t4 = new Terminal("term_4", true);
		t5 = new Terminal("term_5", false);
		
		
//		tArr1 = new Terminal[] {t1, t2};
//		tArr2 = new Terminal[] {t3, t4, t5};
		
		p1 = new Plane(t1, depTime1, crew, passArr1);
		p2 = new Plane(t2, depTime2, crew, passArr1);
		
		p1.allocateSeat(passArr1[1], 2);
		
		
	}
}
