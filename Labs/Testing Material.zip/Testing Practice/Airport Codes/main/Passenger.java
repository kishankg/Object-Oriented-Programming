package main;
//import exceptions.*;

/**
 * 
 * This class represents a passenger on a plane
 * @author Omkar Kanade, Srihari Raju
 *
 */

public class Passenger {
	// fields
	/**
     * The name of the passenger
     */
	private String name;
	/**
     * The ticket number of the passenger
     */
	private String ticketNumber;
	/**
     * The cost of the ticket of the passenger
     */
	private int ticketCost;

	/**
     * A String array denoting the food items chosen by the passenger
     */
	private String[] meal;

	// constructor
	/**
     * Constructor for Passenger object, initializes all its fields
     * @param name Name of the passenger
     * @param ticketNumber Ticket number of the passenger
     * @param ticketCost Cost of the passenger's plane ticket
     * @param meal Meal items chosen by the passenger
     */
	public Passenger (String name, String ticketNumber, int ticketCost, String ...meal) {
		this.name = name;
		this.ticketNumber = ticketNumber;
		this.ticketCost = ticketCost;
		this.meal = meal;
	}

	// getters for ticketNumber, ticketCost, name
	/**
     * Getter method for name
     * @return name
     */
	public String getName () {
		return name;
	}
	
	/**
     * Getter method for ticket number
     * @return ticketNumber
     */
	public String getTicketNumber () {
		return ticketNumber;
	}

	/**
     * Getter method for cost of the ticket
     * @return ticketCost
     */
	public int getTicketCost () {
		return ticketCost;
	}


	/**
	 * This class denotes any additional services availed by the passenger during the journey.
	 */
	public class AddOns {
		// fields
		/**
	     * The additional cost that the passenger must pay for these services
	     */
		private int additionalCost;
		/**
	     * denotes whether the passenger is travelling in business class or economy class.
	     * The field has value true if the passenger is travelling in business class.
	     */
		private boolean isBusinessClass;
		/**
	     * A String array denoting the food items on the plane menu
	     */
		private String mealMenu[];
		/**
	     * An array of prices of the food items in the menu
	     */
		private int mealCost[];

		// constructor
		/**
	     * Constructor for AddOns object. Initialises the fields of the class and initialises 
	     * additionalCost to the cost of meal ordered by the passenger. 
	     * @param mealMenu The food menu on the plane
	     * @param mealCost The cost of each item on the menu
	     * @param isBusinessClass Denotes whether the passenger is travelling in business class
	     */
		public AddOns (String mealMenu[], int mealCost[], boolean isBusinessClass) {
			this.mealMenu = mealMenu;
			this.mealCost = mealCost;
			this.isBusinessClass = isBusinessClass;
			additionalCost = getTotalMealCost();
		}

		/**
	     * calculates and returns the total cost of meal ordered by the passenger.
	     * @return total cost of meal of the passenger
	     */
		public int getTotalMealCost () {
			int cost = 0;
			for (String m1: Passenger.this.meal) {
				for (int i=0; i<mealMenu.length; i++) {
					if (m1.equals(mealMenu[i])) {
						cost += mealCost[i];
					}
				}
			}

			return cost;
		}

		/**
	     * If the passenger is travelling in economy class, then this method upgrades him/her to 
	     * business class and increments additionalCost by the upgrade cost. 
	     * If the passenger is already travelling in business class, then this method does not change anything.
	     * @param upgradeCost denotes the cost required to upgrade a passenger from economy to business class.
	     * @return the value of additionalCost
	     */
		public int upgradeClass (int upgradeCost) {
			if (isBusinessClass) {
				return additionalCost;
			}
			
			isBusinessClass = true;
			additionalCost += upgradeCost;
			return additionalCost;
		}
	}
}