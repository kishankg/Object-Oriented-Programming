package main;
//import exceptions.*;
/**
 * 
 * This class represents a crew on a plane. 
 * A crew can either be the pilot/co-pilot, or the in-flight attendents.
 * @author Omkar Kanade, Sri Hari Raju
 *
 */

public class Crew {
	// fields
	/**
     * The name of the crew
     */
	private String name;
	/**
     * The salary of the crew
     */
	private long salary;
	/**
     * If the crew is a pilot or co-pilot, then this field denotes his/her total experience. 
     * If the crew is an in-flight attendent, then this field is null.
     */
	private Integer experience;

	// constructor
	/**
     * Constructor for Crew object, if the crew is an in-flight attendent. Initializes all its fields.
     * @param name Name of the crew
     * @param salary Salary of the crew
     */
	public Crew (String name, long salary) {
		this.name = name;
		this.salary = salary;
	}

	/**
     * Constructor for Crew object, if the crew is a pilot or co-pilot. Initializes all its fields.
     * @param name Name of the crew
     * @param salary Salary of the crew
     * @param experience The total experience of the pilot/co-pilot
     */
	public Crew (String name, long salary, Integer experience) {
		this.name = name;
		this.salary = salary;
		this.experience = experience;
	}

	// methods
	/**
     * getter method for salary of the crew
     * @return salary of the crew
     */
	public long salary () {
		return salary;
	}

	/**
     * getter method for experience of the crew
     * @return experience of the crew (can be null)
     */
	public Integer getExperience () {
		return experience;
	}
}