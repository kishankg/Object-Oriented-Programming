package main;
import exceptions.*;

/**
 * 
 * This class represents Airport 
 * @author Omkar Kanade, Sri Hari Raju.
 *
 */
public class Airport {
	// fields
	/**
	 * Stores Maximum Number of planes that Airport can have
	 * Initialize capacity to 10 
	 */
	private final int capacity = 10;
	/**
	 *Stores the name of the airport 
	 */
	private String name;
	/**
	 * Stores the objects of the Terminal class in an array
	 */
	private Terminal[] terminals;
	/**
	 * Stores the Objects of plane class in an array, Represents all the planes present in the airport
	 */
	private Plane[] planes;
	/**
	 * Set to true if number of planes are more than capacity of Airport, else false. Initialize inside constructor
	 */
	private boolean capacityExceeded;
	
	/**
	 * Initialize all the fields.
	 * if Number of planes in the argument passed are more than capacity of the airport then 
	 * throw CapacityExceededException.
	 * catch the exception using "catch(CapacityExceededException e)". Call the getMessage function by using the exceptionobject caught.<br>
	 * and also set capacityExceeded to true.
	 * @param name Name of the Airport
	 * @param terminals Array of Terminals in the Airport
	 * @param planes Array of Planes in the Airport
	 */
	
	public Airport (String name, Terminal terminals[], Plane ...planes) {
		if(planes.length > capacity)
		{
			try {
				throw new CapacityExceededException(capacity,name + " Airport");
			}
			catch(CapacityExceededException e)
			{
				e.getMessage();
				capacityExceeded = true;
			}
		}
		
		this.name = name;
		this.terminals = terminals;
		this.planes = planes;
	}

	
	/**
	 * getter method for capacityExceeded field.
	 * @return Returns capacityExceeded
	 */
	public boolean isAirportFull () {
		return capacityExceeded;
	}
	/**
	 * getter method for capacity of the airport, i.e., max number of planes
	 * @return returns the capacity of the airport
	 */
	public int getPlaneCapacity () {
		return capacity;
	}

	// 2 hrs
	/**Count Number of planes that will be leaving within 2 hours of current time.
	 * Here currentTime passed as argument follows same representation as departureTime of {@link Plane} class:<br> 
	 * first element in the array stores hours (24 hours format).<br>
	 * second element in the array stores minutes.<br>
	 * third element in the array stores date, which is a single integer.<br>
	 * 
	 * @return  number of planes that will be leaving within two hours from current time
	 */
	public int getDepartingPlanes (int currentTime[]) {
		int ptime[];
		int count = 0;

		for(int i=0;i<planes.length;i++)
		{
			ptime = planes[i].getDepartureTime();
			if (ptime[2] < currentTime[2]) {
				continue;
			}
			if (ptime[2] == currentTime[2] && currentTime[0] < 22) {
				if(ptime[0]-currentTime[0] >=0 && ptime[0]-currentTime[0] < 2)
				{
					count++;
				}
				else if (ptime[0]-currentTime[0] >=0 && ptime[0]-currentTime[0] == 2) {
					if (ptime[1] < currentTime[1]) {
						count += 1;
					}
				}
			}
			else if (ptime[2] == currentTime[2] && currentTime[0] >= 22) {
				if (ptime[0] > currentTime[0]) {
					count += 1;
				}
				else if (ptime[0] == currentTime[0] && ptime[1] > currentTime[0]) {
					count += 1;
				}
			}
			else if ((ptime[2] == currentTime[2]+1) && currentTime[0] >= 22) {
				int newTime = (currentTime[0] + 2)%24;
				if (newTime-ptime[0] >= 0 && newTime-ptime[0]<2) {
					count += 1;
				}
				else if (newTime-ptime[0] >= 0 && newTime-ptime[0]==2) {
					if (ptime[1] < currentTime[1]) {
						count += 1;
					}
				}
			}
			
		}
		return count;
	}
	/**
	 * Counts number of free Terminals available in the Airport
	 * @return returns the number of free Terminals available in the Airport
	 */

	public int getAvailableTerminals () {
		int free = 0;
		for(int i=0;i<terminals.length;i++)
		{
			if(terminals[i].getAvailability())
				free++;
		}
		return free;

	}	
}