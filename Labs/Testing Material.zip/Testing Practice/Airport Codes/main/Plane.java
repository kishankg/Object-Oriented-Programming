package main;
import exceptions.*;
import java.lang.ArithmeticException;

/**
 * 
 * This class represents a plane in the {@link Airport}. 
 * @author Omkar Kanade, Srihari Raju
 *
 */

public class Plane {
	// fields
//	private int capacity;
	/**
     * denotes the terminal where the plane is standing
     */
	private Terminal terminal;
	/**
     * denotes the departure time of the plane<br>
     * the array has length 3 and following are each of its elements:<br>
     * first element : the hour of departure in 24 hour format. This takes values from 0 to 23 (inclusive).<br>
     * second element : the minute of departure. This takes values from 0 to 59 (inclusive).<br>
     * third element : the date of departure. This is a single integer.<br>
     * Example - if a plane departs at 7:30 pm on date 4, then departureTime would be {19, 30, 4}.<br>
     */
	private int[] departureTime;
	/**
     * denotes the {@link Crew}s on the plane. This includes the pilots as well as the in-flight attendents.
     */
	private Crew[] crews;
	/**
     * denotes the {@link Passenger}s on the plane.<br>
     * A passenger's seat number is given by the index of the passenger in this array. 
     * We will assume that the seat numbers are zero-indexed, i.e., they begin with 0.<br>
     * Note: It is possible for some seats to have no passenger. Those seats will be null in the array.
     */
	private Passenger[] passengers;

	// constructor
	/**
     * Constructor for Plane object. Initializes all its fields.<br>
     * NOTE: the fields are initialized only if the terminal is available. If the terminal is 
     * unavailable, then do not do anything.<br>
     * @param terminal denotes the terminal for the plane
     * @param departureTime an int array of size 3 denoting the departure time of the plane
     * @param crews this is the array of crews on the plane
     * @param passengers denotes a variable number of passengers on the plane
     */
	public Plane (Terminal terminal, int departureTime[], Crew crews[], Passenger ...passengers) {
//		this.capacity = capacity;
		if (terminal.getAvailability() == true) {
			this.terminal = terminal;
			this.departureTime = departureTime;
			this.crews = crews;
			this.passengers = passengers;
		}
//		else {
//			this.terminal = null;
//		}
		
//		this.departureTime = departureTime;
//		this.crews = crews;
//		this.passengers = passengers;
	}

	// methods
	/**
	 * getter method for departure time of the plane
	 * @return departure time of the plane 
	 */
	public int[] getDepartureTime () {
		return departureTime;
	}
	
	/**
	 * this method calculates and returns the average ticket price across all passengers on the plane<br>
	 * use the formula : Avg ticket price = (Sum of ticket price of all passengers on the plane)/(total number of passengers on the plane)<br>
	 * Note that the division is integer division; do not use float or double anywhere in the calculation.<br>
	 * IMPORTANT : Some (or all) of the seats in the plane may be empty. Your code must take care of possible 
	 * NullPointerException and ArithmeticException.<br>
	 * If a NullPointerException is raised, print ("No passenger on seat number "+ seat number) using System.out.println().<br>
	 * If a ArithmeticException is raised, print ("Zero passengers") using System.out.println().<br>
	 * @return If there are more than 0 passengers, return the average ticket price of all passengers on the plane. Else, return -1.<br>
	 */
	public int getAverageTicketPrice () {
		// raises NullPointerException & DivideByZeroException
		int totalPrice = 0;
		int totalPassengers = 0;
		for (int p=0; p<passengers.length; p++) {
			try {
				int price = passengers[p].getTicketCost();
				totalPrice += price;
				totalPassengers += 1;
			}
			catch (NullPointerException e) {
				// passenger is not there
				System.out.println("No passenger on seat number "+p);
			}
		}

		int averagePrice = 0;
		try {
			averagePrice = (totalPrice/totalPassengers);
		}
		catch (ArithmeticException e) {
			System.out.println("Zero passengers");
			return -1;
		}

		return averagePrice;
	}

	/**
	 * this method returns the boarding time for the plane. The boarding time is exactly 1 hour before the 
	 * departure time of the plane. Do refer to the format of departureTime and return the boarding time in 
	 * the same format.<br>
	 * Eg. if departureTime is {8, 45, 10}, boarding time will be {7, 45, 10}.<br>
	 * @return boarding time for the plane<br>
	 */
	public int[] getBoardingTime () {
		// 1 hr before departure time
		int boardingTime[] = new int[3];
		boardingTime[1] = departureTime[1];
		if (departureTime[0] < 1) {
			boardingTime[0] = 23;
			boardingTime[2] = (departureTime[2] - 1);
		}
		else {
			boardingTime[0] = (departureTime[0] - 1);
			boardingTime[2] = departureTime[2];
		}

		return boardingTime;
	}

	/**
	 * this method validates the tickets of all passengers on the plane.<br>
	 * If any two passengers have tickets with identical ticket numbers, then this method raises 
	 * a {@link DuplicateTicketsException} and returns false.<br>
	 * If no two passengers have identical ticket numbers, then return true.<br>
	 * @return true if the tickets are valid, false otherwise<br>
	 */
	public boolean validateTickets () {
		// raises DuplicateTicketException & NullPointerException
		for (int p=1; p<passengers.length; p++) {
			for (int q=0; q<p; q++) {
				try {
					String ticket_1 = passengers[p].getTicketNumber();
					String ticket_2 = passengers[q].getTicketNumber();

					if (ticket_1.equals(ticket_2)) {
						throw new DuplicateTicketsException(passengers[p], passengers[q]);
					}
				}
				catch (DuplicateTicketsException e) {
					// two passengers have the same ticket number
					e.getMessage();
					return false;
				}
				catch (NullPointerException e) {
//					System.out.println("");
				}
			}
		}

		return true;
	}

	// public Passenger getPassengerAtSeat (int seatNumber) {
	// 	try {
	// 		Passenger passenger = passengers[seatNumber];
	// 		return passenger;
	// 	}
	// 	catch (IndexOutOfBoundsException) {
	// 		// seatNumber > capacity
	// 	}
	// }

	/**
	 * getter method for the passenger array
	 * @return the passenger array for this plane
	 */
	public Passenger[] getPassengerList () {
		return passengers;
	}

	/**
	 * this method allocates the given seatNumber to the given passenger.<br>
	 * If the seatNumber is greater than the number of seats on the plane, then it raises 
	 * an IndexOutOfBoundsException.<br>
	 * If IndexOutOfBoundsException is raised, print ("seat number " + seatNumber), where seatNumber is the passed argument.<br>
	 * If the seat number is valid, check if the seat is empty. If empty, then allocate the passenger to the seat and return true.<br>
	 * If the seat is not empty, return false.
	 * IMPORTANT : take care of possible NullPointerExceptions. If it is raised, return false.<br>
	 * @param passenger the passenger to be allocated
	 * @param seatNumber the corresponding seat number
	 * @return true if the seat was successfully allocated to the passenger, false otherwise
	 */
	public boolean allocateSeat (Passenger passenger, int seatNumber) {
		try {
			if (passengers[seatNumber].equals(null)) {
			}
			return false;
		}
		catch (IndexOutOfBoundsException e) {
			System.out.println("seat number " + e.getMessage());
			return false;
		}
		catch (NullPointerException e) {
			passengers[seatNumber] = passenger;
			return true;
		}
	}

	/**
	 * this method changes the given passenger's plane from this plane to the given second plane.<br>
	 * NOTE : assume that the given passenger is present in the passenger list of this plane<br>
	 * If the second plane does not have an empty seat, return -1.<br>
	 * Otherwise, the given passenger is allocated an empty seat with the smallest seat number on the second plane.<br>
	 * Once the passenger is allocated a seat on the second plane, the seat of the passenger on this plane should become null.<br>
	 * If the allocation is successful, return the seat number of the passenger on the second plane.<br>
	 * IMPORTANT : take care of possible NullPointerExceptions. The code should not terminate due to unhandled NullPointerException.<br>
	 * 
	 * @param passenger the passenger whose plane is to be changed
	 * @param secondPlane the plane to which the passenger is to be allocated
	 * @return the seat number of the passenger on the second plane if allocation is successful, -1 otherwise.
	 */
	public int changePlane (Passenger passenger, Plane secondPlane) {
		// returns the seat number on the new plane, -1 otherwise
		Passenger firstPassengers[] = this.getPassengerList();
		Passenger secondPassengers[] = secondPlane.getPassengerList();

		int emptySeat = -1;
		boolean flag = false;
		for (int p=0; p<secondPassengers.length; p++) {
			try {
				if (secondPassengers[p].equals(null)) {}
			}
			catch (NullPointerException e) {
				flag = true;
				emptySeat = p;
				break;
			}
		}

		if (flag == false) {
			return -1;
		}

		for (int p=0; p<firstPassengers.length; p++) {
			if (passenger.equals(firstPassengers[p])) {
				this.allocateSeat(null, p);
				secondPlane.allocateSeat(passenger, emptySeat);
				break;
			}
		}

		return emptySeat;
	}

	// public int getPilotSalary () {

	// }

	// public int getOtherCrewSalary () {

	// }

}