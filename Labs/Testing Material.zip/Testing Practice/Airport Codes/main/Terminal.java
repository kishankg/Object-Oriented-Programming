package main;
import exceptions.*;

/**
 * 
 * This class represents a terminal in the {@link Airport}. 
 * @author Omkar Kanade, Sri Hari Raju
 *
 */
public class Terminal {
	// fields
	/**
     * name of the terminal
     */
	private String name;
	/**
     * denotes whether the terminal is currently available or not
     */
	private boolean availability;
//	private int capacity;

	// constructor
	/**
     * Constructor for Terminal object. Initializes all its fields.
     * @param name Name of the terminal
     * @param availability Availability of the terminal
     */
	public Terminal (String name, boolean availability) {
		this.name = name;
		this.availability = availability;
//		this.capacity = capacity;
	}

	// methods
	/**
     * getter method for name of the Terminal
     * @return name of the terminal
     */
	public String getName () {
		return name;
	}
	
	/**
     * checks the availability of the terminal.<br>
     * If the terminal is available, the method returns true<br>
     * If the terminal is not available, then the method raises a {@link NotAvailableException} 
     * and returns false.
     * @return availability of the terminal
     */
	public boolean getAvailability () {
		// raises NotAvailableException
		try {
			if (availability == false) {
				throw new NotAvailableException(name);
			}
		}
		catch (NotAvailableException e) {
			e.getMessage();
			return false;
		}
		
		return true;
	}
}