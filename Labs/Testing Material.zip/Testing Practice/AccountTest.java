import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.io.*;

/**
 * The test class Account class
 *
 * @author  
 * @version 24 January, 2019
 */

public class AccountTest {

    private Account account;
    

    @Before
    public void setUp(){
        account = new Account(1, "xyz", "1/1/19", 1000, 5);
    }

    @After
    public void tearDown(){
        account  = null;
    }
    
    // 1 
    @Test
    public void testBalance(){

        assertEquals(account.getBalance(), 1000, 0);

    }

    // 2
    @Test 
    public void testDeposit(){
        assertTrue(account.deposit(500.0));
        assertEquals(account.getBalance(), 1500, 0);
        assertTrue(account.deposit(1000.45));
        assertEquals(account.getBalance(), 2500, 0);

    }

    // 2
    @Test
    public void testLoan(){
        assertEquals(account.takeLoan(100.5, 10, 2), 120, 0);
        assertEquals(account.getBalance(), 1100, 0);
    }

    // 2
    @Test
    public void testWithdraw_1(){
        assertTrue(account.withdraw(400));
        assertEquals(account.getBalance(), 600, 0);
        assertTrue(account.withdraw(200.6));
        assertEquals(account.getBalance(), 399, 0);
    }

    // 2
    @Test
    public void testWithdraw_2(){
        assertFalse(account.withdraw(4000));
        assertEquals(account.getBalance(), 1000, 0);
        assertFalse(account.withdraw(2000.6));
        assertEquals(account.getBalance(), 1000, 0);
    }
    
    // 1
    @Test
    public void testInterestOnDeposit(){
        assertEquals(account.interestOnDeposit(2), 100, 0);
        assertEquals(account.getBalance(), 1000, 0);
        assertEquals(account.interestOnDeposit(4), 200, 0);
        assertEquals(account.getBalance(), 1000, 0);
    }
    
}
